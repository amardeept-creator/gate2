-- GateFlow schema for Postgres (Neon / Vercel Postgres).
-- Ported from the original Cloudflare D1 (SQLite) schema.sql.
-- Boolean-style flag columns are kept as INTEGER (0/1), matching the
-- original app code's `column=1` comparisons and 1/0 bind values.
-- Safe to run multiple times.

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  password_salt TEXT NOT NULL,
  name TEXT NOT NULL,
  mobile TEXT,
  role TEXT NOT NULL CHECK(role IN ('MASTER_ADMIN','SOCIETY_SECRETARY','GUARD')),
  society_id TEXT,
  active INTEGER NOT NULL DEFAULT 1,
  shift TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_users_society ON users(society_id);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);

CREATE TABLE IF NOT EXISTS societies (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  address TEXT,
  city TEXT,
  state TEXT,
  pin TEXT,
  logo_url TEXT,
  blocks_count INTEGER DEFAULT 0,
  flats_count INTEGER DEFAULT 0,
  contact TEXT,
  emergency_contact TEXT,
  settings_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS blocks (
  id TEXT PRIMARY KEY,
  society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  floor_count INTEGER DEFAULT 0,
  created_at TEXT NOT NULL,
  UNIQUE(society_id,name)
);
CREATE INDEX IF NOT EXISTS idx_blocks_society ON blocks(society_id);

CREATE TABLE IF NOT EXISTS flats (
  id TEXT PRIMARY KEY,
  society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
  block_id TEXT NOT NULL REFERENCES blocks(id) ON DELETE CASCADE,
  flat_number TEXT NOT NULL,
  floor INTEGER DEFAULT 0,
  owner_name TEXT,
  resident_type TEXT,
  active INTEGER DEFAULT 1,
  created_at TEXT NOT NULL,
  UNIQUE(block_id,flat_number)
);
CREATE INDEX IF NOT EXISTS idx_flats_society ON flats(society_id);

CREATE TABLE IF NOT EXISTS residents (
  id TEXT PRIMARY KEY,
  society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
  flat_id TEXT NOT NULL REFERENCES flats(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  mobile TEXT,
  whatsapp TEXT,
  alternate_number TEXT,
  email TEXT,
  family_members TEXT,
  vehicle_details TEXT,
  resident_type TEXT,
  active INTEGER DEFAULT 1,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_residents_society ON residents(society_id);

CREATE TABLE IF NOT EXISTS visitor_types (
  id TEXT PRIMARY KEY,
  society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  icon TEXT DEFAULT '👤',
  color TEXT DEFAULT '#4F46E5',
  description TEXT,
  photo_required INTEGER DEFAULT 0,
  flat_required INTEGER DEFAULT 1,
  approval_required INTEGER DEFAULT 0,
  id_required INTEGER DEFAULT 0,
  vehicle_required INTEGER DEFAULT 0,
  phone_required INTEGER DEFAULT 1,
  active INTEGER DEFAULT 1,
  sort_order INTEGER DEFAULT 0,
  created_at TEXT NOT NULL,
  UNIQUE(society_id,name)
);
CREATE INDEX IF NOT EXISTS idx_vtypes_society ON visitor_types(society_id);

CREATE TABLE IF NOT EXISTS visitor_fields (
  id TEXT PRIMARY KEY,
  visitor_type_id TEXT NOT NULL REFERENCES visitor_types(id) ON DELETE CASCADE,
  label TEXT NOT NULL,
  field_key TEXT NOT NULL,
  field_type TEXT NOT NULL,
  required INTEGER DEFAULT 0,
  options_json TEXT DEFAULT '[]',
  sort_order INTEGER DEFAULT 0,
  active INTEGER DEFAULT 1,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_vfields_type ON visitor_fields(visitor_type_id);

CREATE TABLE IF NOT EXISTS visitors (
  id TEXT PRIMARY KEY,
  society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
  visitor_type_id TEXT NOT NULL REFERENCES visitor_types(id),
  flat_id TEXT REFERENCES flats(id),
  resident_id TEXT REFERENCES residents(id),
  name TEXT NOT NULL,
  mobile TEXT,
  vehicle_number TEXT,
  id_number TEXT,
  photo_key TEXT,
  custom_data_json TEXT NOT NULL DEFAULT '{}',
  status TEXT NOT NULL CHECK(status IN ('Waiting','Approved','Rejected','Entered','Exited','Cancelled')),
  entry_at TEXT,
  exit_at TEXT,
  entry_guard_id TEXT REFERENCES users(id),
  exit_guard_id TEXT REFERENCES users(id),
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_visitors_society_time ON visitors(society_id,created_at);
CREATE INDEX IF NOT EXISTS idx_visitors_status ON visitors(society_id,status);

CREATE TABLE IF NOT EXISTS approvals (
  id TEXT PRIMARY KEY,
  visitor_id TEXT NOT NULL REFERENCES visitors(id) ON DELETE CASCADE,
  resident_id TEXT REFERENCES residents(id),
  status TEXT NOT NULL CHECK(status IN ('Waiting','Approved','Rejected')),
  decided_at TEXT,
  note TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  society_id TEXT NOT NULL REFERENCES societies(id) ON DELETE CASCADE,
  visitor_id TEXT,
  channel TEXT NOT NULL,
  event_type TEXT NOT NULL,
  recipient TEXT,
  provider TEXT,
  status TEXT NOT NULL DEFAULT 'queued',
  payload_json TEXT DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  user_id TEXT REFERENCES users(id),
  role TEXT,
  action TEXT NOT NULL,
  society_id TEXT,
  record_id TEXT,
  metadata_json TEXT DEFAULT '{}',
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_society_time ON audit_logs(society_id,created_at);

CREATE TABLE IF NOT EXISTS society_settings (
  society_id TEXT PRIMARY KEY REFERENCES societies(id) ON DELETE CASCADE,
  notification_json TEXT NOT NULL DEFAULT '{}',
  permission_json TEXT NOT NULL DEFAULT '{}',
  updated_at TEXT NOT NULL
);
