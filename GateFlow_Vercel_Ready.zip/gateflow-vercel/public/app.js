const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const state={user:null,view:'dashboard',society:null,types:[],selectedType:null,fields:[],blocks:[],flats:[],residents:[],visitors:[]};

async function api(path,opts={}){
  const r=await fetch('/api/'+path,{credentials:'same-origin',headers:{'content-type':'application/json',...(opts.headers||{})},...opts});
  const data=r.headers.get('content-type')?.includes('json')?await r.json():await r.text();
  if(!r.ok) throw new Error(data?.error||data||'Request failed');
  return data;
}
function toast(msg,bad=false){const e=document.createElement('div');e.textContent=msg;e.style.cssText=`position:fixed;right:18px;bottom:18px;z-index:100;padding:13px 16px;border-radius:12px;background:${bad?'#991b1b':'#111827'};color:#fff;box-shadow:0 10px 30px #0003`;document.body.appendChild(e);setTimeout(()=>e.remove(),3000)}
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=d=>d?new Date(d).toLocaleString([], {dateStyle:'medium',timeStyle:'short'}):'—';
const initials=n=>String(n||'?').split(/\s+/).map(x=>x[0]).slice(0,2).join('').toUpperCase();

async function boot(){
  const m=await api('auth/me');
  if(m.user){state.user=m.user; await loadPortal(); render();}
  else {
    const s=await api('auth/setup-status');
    renderLogin(s.setupRequired);
  }
}
function renderLogin(setup=false){
  document.body.innerHTML=`<div class="login"><div class="login-card">
    <div class="logo"><div class="logo-mark">🛡</div><div>GateFlow<div class="muted" style="font-size:12px">Society Visitor Management</div></div></div>
    <h1>${setup?'Create Master Admin':'Welcome back'}</h1>
    <p class="muted">${setup?'One-time secure setup for your private control panel.':'Sign in to your assigned GateFlow portal.'}</p>
    <form id="loginForm">
      ${setup?`<label class="field">Setup key<input id="setupKey" type="password" required placeholder="Worker secret MASTER_SETUP_KEY"></label>`:''}
      <label class="field">Admin ID / Username<input id="username" autocomplete="username" required></label>
      <label class="field">Name${setup?'<input id="name" required>':''}</label>
      ${setup?'<label class="field">Mobile (optional)<input id="mobile"></label>':''}
      <label class="field">Password<input id="password" type="password" autocomplete="current-password" required></label>
      <button class="btn primary block">${setup?'Create Master Admin':'Sign in'}</button>
    </form>
    <p class="muted" style="font-size:12px;margin:14px 0 0">Credentials are never stored in browser localStorage.</p>
  </div></div>`;
  $('#loginForm').onsubmit=async e=>{
    e.preventDefault();
    try{
      if(setup) await api('auth/setup',{method:'POST',body:JSON.stringify({setupKey:$('#setupKey').value,username:$('#username').value,name:$('#name').value,mobile:$('#mobile').value,password:$('#password').value})});
      else await api('auth/login',{method:'POST',body:JSON.stringify({username:$('#username').value,password:$('#password').value})});
      location.reload();
    }catch(err){toast(err.message,true)}
  };
}
async function loadPortal(){
  if(state.user.role==='MASTER_ADMIN') return;
  const p=await api('portal');state.society=p.society;state.types=p.types;
}
function navItems(){
  if(state.user.role==='MASTER_ADMIN') return [
    ['dashboard','⌂','Dashboard'],['societies','▦','Societies'],['people','♙','Users & Residents'],['config','⚙','Visitor Types & Fields'],['reports','▤','Reports'],['audit','◷','Audit Logs'],['demo','✦','Demo Data']
  ];
  if(state.user.role==='SOCIETY_SECRETARY') return [['dashboard','⌂','Dashboard'],['register','＋','New Visitor'],['history','▤','Visitor History'],['residents','♙','Residents'],['config','⚙','Visitor Types'],['reports','▤','Reports']];
  return [['dashboard','⌂','Dashboard'],['register','＋','New Visitor'],['inside','◉','Currently Inside'],['history','▤','Visitor History']];
}
function render(){
  document.body.innerHTML=`<div class="shell"><aside class="side" id="side"><div class="logo"><div class="logo-mark">🛡</div><div>GateFlow<div style="font-size:11px;color:#94a3b8">${esc(state.user.role.replaceAll('_',' '))}</div></div></div>
    <nav>${navItems().map(x=>`<button class="nav ${state.view===x[0]?'active':''}" data-view="${x[0]}">${x[1]} &nbsp; ${x[2]}</button>`).join('')}</nav>
    <div class="side-foot"><button class="btn" style="width:100%" id="logout">Sign out</button></div></aside>
    <main class="main"><div class="top"><div><button class="btn mobile-menu" id="menu">☰</button> <h1 style="display:inline">${title()}</h1></div>
    <div class="userbox"><div class="avatar">${initials(state.user.name)}</div><div class="hide-m"><b>${esc(state.user.name)}</b><div class="muted" style="font-size:11px">${esc(state.society?.name||'Global Master Admin')}</div></div></div></div>
    <div id="content"></div></main></div>`;
  $$('.nav').forEach(b=>b.onclick=()=>{state.view=b.dataset.view;$('#side').classList.remove('open');render()});
  $('#logout').onclick=async()=>{await api('auth/logout',{method:'POST'});location.reload()};
  $('#menu').onclick=()=>$('#side').classList.toggle('open');
  renderView();
}
function title(){return ({dashboard:'Dashboard',societies:'Societies',people:'Users & Residents',config:'Configuration',reports:'Reports',audit:'Audit Logs',demo:'Demo Data',register:'New Visitor',inside:'Currently Inside',history:'Visitor History',residents:'Residents'})[state.view]||'GateFlow'}
async function renderView(){
  const c=$('#content'); c.innerHTML='<div class="card empty">Loading…</div>';
  try{
    if(state.view==='dashboard') return await dashboard(c);
    if(state.view==='societies') return await societies(c);
    if(state.view==='people'||state.view==='residents') return await people(c);
    if(state.view==='config') return await config(c);
    if(state.view==='register') return await register(c);
    if(state.view==='inside'||state.view==='history') return await visitorList(c,state.view);
    if(state.view==='reports') return await reports(c);
    if(state.view==='audit') return await auditView(c);
    if(state.view==='demo') return await demo(c);
  }catch(e){c.innerHTML=`<div class="card"><b>Could not load</b><p class="muted">${esc(e.message)}</p></div>`}
}
async function dashboard(c){
  const d=state.user.role==='MASTER_ADMIN'?await api('admin/dashboard'):await api('dashboard');
  if(state.user.role==='MASTER_ADMIN'){
    c.innerHTML=`<div class="grid stats">${[['Total societies',d.stats.societies],['Active societies',d.stats.activeSocieties],['Guards',d.stats.guards],['Secretaries',d.stats.secretaries],['Flats',d.stats.flats],['Residents',d.stats.residents],["Today's visitors",d.stats.todayVisitors],['Currently inside',d.stats.inside],["Today's exits",d.stats.exited],["Today's deliveries",d.stats.delivery],["Today's maid entries",d.stats.maids]].map(x=>`<div class="card stat"><div class="label">${x[0]}</div><div class="num">${x[1]}</div></div>`).join('')}</div>
      <div class="grid two" style="margin-top:16px"><div class="card"><div class="section-head"><h2>Recent activity</h2></div>${table(d.recent,['name','type','society','block','flat_number','status','created_at'])}</div>
      <div class="card"><div class="section-head"><h2>Society comparison</h2></div>${table(d.societies,['name','visitors','active'])}</div></div>`;
  }else{
    c.innerHTML=`<div class="grid stats">${[['Today',d.today],['Currently inside',d.inside],["Today's exits",d.exits],['All visitors',d.total]].map(x=>`<div class="card stat"><div class="label">${x[0]}</div><div class="num">${x[1]}</div></div>`).join('')}</div>
    <div class="card" style="margin-top:16px"><div class="section-head"><h2>Visitor type activity</h2><button class="btn primary" onclick="state.view='register';render()">＋ New Visitor</button></div>${table(d.types,['type','count'])}</div>`;
  }
}
function table(rows,cols){
  if(!rows?.length)return '<div class="empty">No records yet.</div>';
  return `<div class="table-wrap"><table class="table"><thead><tr>${cols.map(x=>`<th>${x.replaceAll('_',' ')}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${cols.map(c=>`<td>${c==='status'?badge(r[c]):esc(r[c]??'—')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}
function badge(s){let cls=s==='Entered'||s==='Approved'?'ok':(s==='Rejected'?'bad':(s==='Waiting'?'warn':''));return `<span class="badge ${cls}">${esc(s)}</span>`}
async function societies(c){
  const rows=await api('societies');
  c.innerHTML=`<div class="card"><div class="section-head"><h2>All societies</h2><button class="btn primary" id="addSoc">＋ Create Society</button></div>${table(rows,['name','city','state','flat_count','resident_count','guard_count','active'])}</div>`;
  $('#addSoc').onclick=()=>modal('Create Society',`<form id="f" class="formgrid">
    ${field('Society name','name',true)}${field('Address','address')}${field('City','city')}${field('State','state')}${field('PIN','pin')}${field('Contact','contact')}${field('Emergency contact','emergencyContact')}
    <div class="span2 actions"><button class="btn primary">Create Society</button></div></form>`,async()=>{const b=formData($('#f'));await api('societies',{method:'POST',body:JSON.stringify(b)});toast('Society created');render()});
}
async function people(c){
  const sid=state.user.role==='MASTER_ADMIN'?new URLSearchParams(location.search).get('societyId'):state.user.societyId;
  if(state.user.role==='MASTER_ADMIN'&&!sid){
    const rows=await api('societies'); c.innerHTML=`<div class="card"><h2>Select a society</h2><p class="muted">Open a society to manage its users, blocks, flats and residents.</p>${rows.map(r=>`<button class="btn" style="margin:5px" onclick="location.search='?societyId=${r.id}'">${esc(r.name)}</button>`).join('')}</div>`;return;
  }
  const [users,blocks,flats,residents]=await Promise.all([api('users?'+(sid?'societyId='+sid:'')),api('blocks?'+(sid?'societyId='+sid:'')),api('flats?'+(sid?'societyId='+sid:'')),api('residents?'+(sid?'societyId='+sid:'')+'')]);
  c.innerHTML=`<div class="grid two"><div class="card"><div class="section-head"><h2>Users</h2><button class="btn primary" id="addUser">＋ User</button></div>${table(users,['name','username','role','mobile','shift','active'])}</div>
  <div class="card"><div class="section-head"><h2>Residents</h2><button class="btn primary" id="addResident">＋ Resident</button></div>${table(residents,['name','block_name','flat_number','whatsapp','mobile'])}</div></div>
  <div class="grid two" style="margin-top:16px"><div class="card"><div class="section-head"><h2>Blocks</h2><button class="btn primary" id="addBlock">＋ Block</button></div>${table(blocks,['name','floor_count'])}</div><div class="card"><div class="section-head"><h2>Flats</h2><button class="btn primary" id="addFlat">＋ Flat</button></div>${table(flats,['block_name','flat_number','floor','owner_name','residents'])}</div></div>`;
  $('#addUser').onclick=()=>modal('Create Guard / Secretary',`<form id="f" class="formgrid">${field('Name','name',true)}${field('Username','username',true)}${field('Mobile','mobile')}${field('Password (10+ chars)','password',true,'password')}${select('Role','role',['GUARD','SOCIETY_SECRETARY'])}${field('Shift','shift')}<div class="span2"><button class="btn primary">Create</button></div></form>`,async()=>{const b=formData($('#f'));b.societyId=sid;await api('users',{method:'POST',body:JSON.stringify(b)});toast('User created');render()});
  $('#addBlock').onclick=()=>modal('Create Block',`<form id="f">${field('Block name','name',true)}${field('Floor count','floorCount')}<button class="btn primary">Create</button></form>`,async()=>{const b=formData($('#f'));b.societyId=sid;await api('blocks',{method:'POST',body:JSON.stringify(b)});toast('Block created');render()});
  $('#addFlat').onclick=()=>modal('Create Flat',`<form id="f" class="formgrid">${select('Block','blockId',blocks.map(x=>[x.id,x.name]))}${field('Flat number','flatNumber',true)}${field('Floor','floor')}${field('Owner name','ownerName')}<div class="span2"><button class="btn primary">Create</button></div></form>`,async()=>{const b=formData($('#f'));b.societyId=sid;await api('flats',{method:'POST',body:JSON.stringify(b)});toast('Flat created');render()});
  $('#addResident').onclick=()=>modal('Add Resident',`<form id="f" class="formgrid">${select('Flat','flatId',flats.map(x=>[x.id,`${x.block_name} ${x.flat_number}`]))}${field('Resident name','name',true)}${field('Mobile','mobile')}${field('WhatsApp','whatsapp')}${field('Alternate','alternateNumber')}${field('Email','email')}<div class="span2"><button class="btn primary">Create</button></div></form>`,async()=>{const b=formData($('#f'));b.societyId=sid;await api('residents',{method:'POST',body:JSON.stringify(b)});toast('Resident added');render()});
}
async function config(c){
  const sid=state.user.role==='MASTER_ADMIN'?new URLSearchParams(location.search).get('societyId'):state.user.societyId;
  if(state.user.role==='MASTER_ADMIN'&&!sid){const rows=await api('societies');c.innerHTML=`<div class="card"><h2>Select society</h2>${rows.map(r=>`<button class="btn" style="margin:5px" onclick="location.search='?societyId=${r.id}'">${esc(r.name)}</button>`).join('')}</div>`;return}
  const types=await api('visitor-types?'+(sid?'societyId='+sid:'')); state.types=types;
  c.innerHTML=`<div class="section-head"><div><h2>Dynamic visitor types</h2><p class="muted">No visitor category is hard-coded. Add categories and fields from this panel.</p></div><button class="btn primary" id="addType">＋ Add Visitor Type</button></div><div class="grid three">${types.map(t=>`<div class="card"><div style="font-size:28px">${esc(t.icon)}</div><h3>${esc(t.name)}</h3><p class="muted">${esc(t.description||'')}</p><div>${t.approval_required?badge('Approval required'):badge('No approval')}</div><button class="btn" style="margin-top:12px" onclick="editFields('${t.id}','${esc(t.name)}')">Configure fields</button></div>`).join('')}</div>`;
  $('#addType').onclick=()=>modal('Add Visitor Type',`<form id="f" class="formgrid">${field('Name','name',true)}${field('Icon','icon')}${field('Color','color')}${field('Description','description')}<label class="field"><span>Approval required</span><input type="checkbox" name="approvalRequired"></label><label class="field"><span>Photo mandatory</span><input type="checkbox" name="photoRequired"></label><label class="field"><span>Flat mandatory</span><input type="checkbox" name="flatRequired" checked></label><label class="field"><span>Phone mandatory</span><input type="checkbox" name="phoneRequired" checked></label><div class="span2"><button class="btn primary">Create</button></div></form>`,async()=>{const b=formData($('#f'));b.societyId=sid;await api('visitor-types',{method:'POST',body:JSON.stringify(b)});toast('Visitor type created');render()});
}
window.editFields=async(tid,name)=>{
  const fs=await api(`visitor-types/${tid}/fields`);
  modal(`Fields — ${name}`,`<div id="fieldList">${fs.map(f=>`<div class="card" style="padding:10px;margin:7px 0"><b>${esc(f.label)}</b><span class="muted"> · ${esc(f.field_type)} · ${f.required?'required':'optional'}</span></div>`).join('')}</div><hr><form id="f" class="formgrid">${field('Label','label',true)}${field('Field key','fieldKey',true)}${select('Field type','fieldType',['text','number','phone','dropdown','date','time','datetime','checkbox','radio','longtext','photo','vehicle','id'])}<label class="field"><span>Required</span><input type="checkbox" name="required"></label><div class="span2"><button class="btn primary">Add field</button></div></form>`,async()=>{const b=formData($('#f'));b.sortOrder=fs.length;await api(`visitor-types/${tid}/fields`,{method:'POST',body:JSON.stringify(b)});toast('Field added');editFields(tid,name)});
};
async function register(c){
  const types=state.types.length?state.types:await api('visitor-types');
  const [blocks,flats,residents]=await Promise.all([api('blocks'),api('flats'),api('residents?q=')]);
  state.blocks=blocks;state.flats=flats;state.residents=residents;
  c.innerHTML=`<div class="card"><div class="section-head"><div><h2>Fast visitor entry</h2><p class="muted">Choose the configured visitor type; only its fields are shown.</p></div></div>
  <div class="type-grid">${types.map(t=>`<button class="type" data-t="${t.id}"><span style="font-size:28px">${esc(t.icon)}</span><strong>${esc(t.name)}</strong><span class="muted">${t.approval_required?'Approval':'Direct entry'}</span></button>`).join('')}</div><div id="visitorForm" style="margin-top:18px"></div></div>`;
  $$('.type').forEach(b=>b.onclick=async()=>{state.selectedType=types.find(t=>t.id===b.dataset.t);$$('.type').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');state.fields=await api(`visitor-types/${state.selectedType.id}/fields`);drawVisitorForm()});
  function drawVisitorForm(){
    const t=state.selectedType, fields=state.fields;
    $('#visitorForm').innerHTML=`<form id="vf" class="formgrid">
      ${fields.map(f=>renderField(f)).join('')}
      ${t.flat_required?`${select('Block','blockId',blocks.map(x=>[x.id,x.name]))}${select('Flat','flatId',[])}<div class="span2" id="residentBox"></div>`:''}
      ${t.photo_required||true?`<div class="span2 camera"><b>Visitor photo</b><video id="video" playsinline class="hidden"></video><canvas id="canvas" class="hidden"></canvas><img id="photoPreview" class="hidden"><div class="actions" style="justify-content:center;margin-top:10px"><button type="button" class="btn" id="cam">📷 Take Photo</button><button type="button" class="btn hidden" id="snap">Capture</button><button type="button" class="btn hidden" id="retake">Retake</button></div></div>`:''}
      <div class="span2 actions"><button class="btn primary">Confirm Entry</button></div></form>`;
    const blk=$('#blockId'), flat=$('#flatId');
    if(blk)blk.onchange=()=>{const fs=flats.filter(x=>x.block_id===blk.value);flat.innerHTML='<option value="">Select flat</option>'+fs.map(x=>`<option value="${x.id}">${esc(x.flat_number)}</option>`).join('');$('#residentBox').innerHTML=''};
    if(flat)flat.onchange=()=>{const rs=residents.filter(x=>x.flat_id===flat.value);$('#residentBox').innerHTML=rs.length?`<div class="resident"><b>Resident: ${esc(rs[0].name)}</b><div class="muted">${esc(rs[0].block_name)} ${esc(rs[0].flat_number)} · notification number stored securely</div><input type="hidden" name="residentId" value="${rs[0].id}"></div>`:'<div class="resident">No active resident found for this flat.</div>'};
    camera();
    $('#vf').onsubmit=async e=>{e.preventDefault();try{
      const b=formData($('#vf'));b.visitorTypeId=t.id;b.societyId=state.user.societyId;b.customData={};state.fields.forEach(f=>{b.customData[f.field_key]=b[f.field_key]||''});
      if(b.blockId&&!b.flatId)throw Error('Select a flat'); delete b.blockId;
      if(!b.name)throw Error('Visitor name is required');
      const out=await api('visitors',{method:'POST',body:JSON.stringify(b)});
      toast(out.status==='Waiting'?'Visitor is waiting for approval':'Visitor entered successfully');state.view='history';render();
    }catch(err){toast(err.message,true)}};
  }
}
async function camera(){
  const video=$('#video'),cam=$('#cam'),snap=$('#snap'),retake=$('#retake'),canvas=$('#canvas'),preview=$('#photoPreview');let stream=null,photoKey=null;
  cam.onclick=async()=>{try{stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment'},audio:false});video.srcObject=stream;await video.play();video.classList.remove('hidden');cam.classList.add('hidden');snap.classList.remove('hidden')}catch(e){toast('Camera permission denied. You can continue without a photo unless this visitor type requires one.',true)}};
  snap.onclick=async()=>{canvas.width=video.videoWidth;canvas.height=video.videoHeight;canvas.getContext('2d').drawImage(video,0,0);preview.src=canvas.toDataURL('image/jpeg',.78);preview.classList.remove('hidden');video.classList.add('hidden');snap.classList.add('hidden');retake.classList.remove('hidden');if(stream)stream.getTracks().forEach(t=>t.stop());toast('Photo captured for review')};
  retake.onclick=()=>{preview.classList.add('hidden');cam.classList.remove('hidden');retake.classList.add('hidden')};
}
async function visitorList(c,mode){
  const qs=mode==='inside'?'status=Entered':'';const rows=await api('visitors?'+qs);
  c.innerHTML=`<div class="card"><div class="toolbar"><input id="q" class="input" placeholder="Search visitor, mobile, flat or ID"><select id="status"><option value="">All statuses</option><option>Waiting</option><option>Approved</option><option>Entered</option><option>Exited</option><option>Rejected</option></select><button class="btn" id="search">Search</button></div><div id="vt" style="margin-top:14px">${visitorTable(rows)}</div></div>`;
  $('#search').onclick=async()=>{$('#vt').innerHTML=visitorTable(await api(`visitors?q=${encodeURIComponent($('#q').value)}&status=${$('#status').value}`))};
}
function visitorTable(rows){if(!rows.length)return '<div class="empty">No visitor records.</div>';return `<div class="table-wrap"><table class="table"><thead><tr><th>Visitor</th><th>Type</th><th>Flat</th><th>Resident</th><th>Status</th><th>Entry</th><th>Exit</th><th>Action</th></tr></thead><tbody>${rows.map(v=>`<tr><td><b>${esc(v.name)}</b><div class="muted">${esc(v.mobile||'')}</div></td><td>${esc(v.type)}</td><td>${esc((v.block_name||'')+' '+(v.flat_number||''))}</td><td>${esc(v.resident_name||'—')}</td><td>${badge(v.status)}</td><td>${fmt(v.entry_at)}</td><td>${fmt(v.exit_at)}</td><td>${v.status==='Entered'?`<button class="btn small danger" onclick="exitVisitor('${v.id}')">Mark exit</button>`:v.status==='Waiting'&&state.user.role!=='GUARD'?`<button class="btn small ok" onclick="approveVisitor('${v.id}',true)">Approve</button>`:'—'}</td></tr>`).join('')}</tbody></table></div>`}
window.exitVisitor=async id=>{try{await api(`visitors/${id}/exit`,{method:'POST'});toast('Visitor marked exited');state.view='inside';render()}catch(e){toast(e.message,true)}};
window.approveVisitor=async(id,a)=>{try{await api(`visitors/${id}/approve`,{method:'POST',body:JSON.stringify({approved:a})});toast(a?'Approved':'Rejected');render()}catch(e){toast(e.message,true)}};
async function reports(c){
  if(state.user.role==='GUARD')return visitorList(c,'history');
  c.innerHTML=`<div class="card"><h2>Reports</h2><p class="muted">Download up to 5,000 recent visitor rows as CSV, Excel-compatible.</p><button class="btn primary" id="csv">Download CSV</button><button class="btn" style="margin-left:8px" onclick="window.print()">Print report</button></div>`;
  $('#csv').onclick=async()=>{const r=await fetch('/api/reports/csv',{credentials:'same-origin'});const blob=await r.blob();const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='gateflow-visitors.csv';a.click();URL.revokeObjectURL(a.href)};
}
async function auditView(c){
  if(state.user.role!=='MASTER_ADMIN'){c.innerHTML='<div class="card empty">Audit logs are available to Master Admin only.</div>';return}
  const rows=await api('visitors'); // keep page functional; detailed audit endpoint can be added without changing UI
  c.innerHTML='<div class="card"><h2>Audit & accountability</h2><p class="muted">Security-sensitive actions are stored server-side in the <code>audit_logs</code> table. Use D1 Console for full audit export in this build.</p><p>Recent visitor records are not audit records.</p></div>';
}
async function demo(c){
  c.innerHTML=`<div class="card"><h2>Demo Society</h2><p class="muted">Create the demo through the real database/API model. Nothing is seeded into the frontend.</p><button class="btn primary" id="seed">Create GateFlow Demo Residency</button><div id="result" style="margin-top:14px"></div></div>`;
  $('#seed').onclick=async()=>{try{const r=await api('demo/seed',{method:'POST'});$('#result').innerHTML=`<div class="resident"><b>Created successfully.</b><p>Guard: <code>${r.credentials.guard}</code><br>Secretary: <code>${r.credentials.secretary}</code></p><p>Society ID: ${esc(r.societyId)}</p></div>`;toast('Demo created')}catch(e){toast(e.message,true)}};
}
function field(label,name,required=false,type='text'){return `<label class="field"><span>${esc(label)}</span><input name="${name}" id="${name}" type="${type}" ${required?'required':''}></label>`}
function select(label,name,opts){return `<label class="field"><span>${esc(label)}</span><select name="${name}" id="${name}"><option value="">Select ${esc(label)}</option>${opts.map(o=>{let v=Array.isArray(o)?o[0]:o,t=Array.isArray(o)?o[1]:o;return `<option value="${esc(v)}">${esc(t)}</option>`}).join('')}</select></label>`}
function renderField(f){if(f.field_type==='longtext')return `<label class="field span2"><span>${esc(f.label)}</span><textarea name="${f.field_key}" rows="3" ${f.required?'required':''}></textarea></label>`;if(f.field_type==='checkbox')return `<label class="field"><span>${esc(f.label)}</span><input name="${f.field_key}" type="checkbox"></label>`;return field(f.label,f.field_key,!!f.required,f.field_type==='datetime'?'datetime-local':(f.field_type==='vehicle'?'text':f.field_type==='id'?'text':f.field_type))}
function formData(form){const o={};new FormData(form).forEach((v,k)=>o[k]=v);form.querySelectorAll('input[type=checkbox]').forEach(x=>o[x.name]=x.checked);return o}
function modal(title,html,onSubmit){const m=document.createElement('div');m.className='modal';m.innerHTML=`<div class="modal-card"><div class="modal-head"><h2>${esc(title)}</h2><button class="x">×</button></div><div style="margin-top:15px">${html}</div></div>`;document.body.appendChild(m);m.querySelector('.x').onclick=()=>m.remove();m.querySelector('form').onsubmit=async e=>{e.preventDefault();try{await onSubmit();m.remove()}catch(err){toast(err.message,true)}}}
boot();
