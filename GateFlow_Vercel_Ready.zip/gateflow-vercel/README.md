# GateFlow — Multi-Tenant Visitor Management (Vercel edition)

This is the original GateFlow app, ported from Cloudflare (Workers + D1 + R2) to
Vercel (Edge Functions + Postgres).

## What changed from the Cloudflare version

| Cloudflare piece            | Replaced with                                  |
|------------------------------|------------------------------------------------|
| Worker (`worker.js`)         | Vercel Edge Function at `api/[...path].js`     |
| D1 (SQLite)                  | Postgres (Neon / Vercel Postgres)              |
| `env.ASSETS` static serving  | Vercel's built-in static hosting of `public/`  |
| R2 bucket `PHOTOS`           | Not wired up — see note below                  |

All application logic (auth, roles, tenancy, visitors, approvals, reports, audit
logging) is unchanged. The API is still same-origin at `/api/*`, so `public/app.js`
required no edits.

**Photo storage note:** in the original zip, the camera-capture UI never actually
uploaded to R2 either — `photoKey` was captured in the browser but not sent to the
backend, so `photo_key` was always stored as empty. That behavior is preserved
as-is here. If you want photos actually persisted, wire `public/app.js`'s capture
flow to upload to a storage provider (Vercel Blob is a natural fit) and pass the
returned key as `photoKey` when submitting the visitor form.

## Deploy

### 1. Push to GitHub

Create a new GitHub repo and push this folder's contents to it (this whole
directory should be the repo root).

### 2. Create a Postgres database

Easiest: in your Vercel project (after step 3) go to **Storage → Create Database →
Postgres**, or use [Neon](https://neon.tech) directly. Either way you'll get a
connection string.

### 3. Import to Vercel

Vercel Dashboard → **Add New → Project** → import the GitHub repo. No framework
preset needed (leave it as "Other" / auto-detected) — `vercel.json` already tells
Vercel to serve `public/` as the static site, and the `api/` folder deploys
automatically as Edge Functions.

### 4. Set environment variables

In Project Settings → Environment Variables, add (see `.env.example`):

- `DATABASE_URL` — your Postgres connection string
- `MASTER_SETUP_KEY` — a long random value
- `SESSION_DAYS` — optional, defaults to `7`

### 5. Run the schema

Run `schema.postgres.sql` once against your database — e.g. via the Neon SQL
Editor, Vercel Postgres's query tab, or `psql "$DATABASE_URL" -f schema.postgres.sql`.
It's idempotent (`CREATE TABLE IF NOT EXISTS`), safe to re-run.

### 6. Deploy and finish setup

Deploy the project. Open the deployed URL — you'll see **Master Admin first-time
setup** since no master admin exists yet. Create your account (you'll need the
`MASTER_SETUP_KEY` you set above). The setup key is never shown in the app.

## Demo data

Same as before: log in as Master Admin → **Demo Data** → create the demo society.
Demo credentials are shown once, right after creation.

## Local development

```bash
npm install
vercel dev
```

`vercel dev` runs both the static frontend and the Edge Function locally. Put your
env vars in `.env` (see `.env.example`) for local testing — `.env` is gitignored.

## Security notes (unchanged from original)

- Passwords: PBKDF2-SHA-256, per-user random salts, 150k iterations.
- Session tokens are random and stored server-side as hashes.
- Session cookies are HttpOnly, Secure, SameSite=Lax.
- Server-side tenant checks are applied to all society-scoped routes.
- Audit logs record security-sensitive actions (`audit_logs` table).

## Production hardening checklist

- Add a custom domain (Vercel Project Settings → Domains).
- Add rate limiting in front of `/api/auth/*` (e.g. Vercel Firewall rules).
- Configure Postgres backups (Neon/Vercel Postgres both support point-in-time restore).
- Wire a real photo storage + notification provider if you need those features live.
- Rotate `MASTER_SETUP_KEY` / secrets after initial setup.
- Add SSO/2FA if required by your organization.
- Review privacy/retention requirements before storing identity documents/photos.
