import { db } from '../lib/db.js';

export const config = { runtime: 'edge' };

const json = (data, status=200, headers={}) => new Response(JSON.stringify(data), {
  status,
  headers: {'content-type':'application/json; charset=utf-8', ...headers}
});
const text = (data, status=200, headers={}) => new Response(data, {
  status, headers: {'content-type':'text/plain; charset=utf-8', ...headers}
});
const now = () => new Date().toISOString();
const id = (p='id') => `${p}_${crypto.randomUUID().replaceAll('-','')}`;
const escLike = s => `%${String(s||'').replaceAll('%','\\%').replaceAll('_','\\_')}%`;

async function hashPassword(password, saltB64) {
  const salt = saltB64 ? Uint8Array.from(atob(saltB64), c=>c.charCodeAt(0)) : crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2', salt, iterations:150000, hash:'SHA-256'}, key, 256);
  const bytes = new Uint8Array(bits);
  return {
    salt: saltB64 || btoa(String.fromCharCode(...salt)),
    hash: btoa(String.fromCharCode(...bytes))
  };
}
async function hashToken(token) {
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(token));
  return btoa(String.fromCharCode(...new Uint8Array(digest)));
}
const cookie = (name, value, maxAge) =>
  `${name}=${value}; Max-Age=${maxAge}; Path=/; HttpOnly; Secure; SameSite=Lax`;

async function body(req){ try{return await req.json()}catch{return {}} }
function requireFields(o, fields){ return fields.find(f=>o[f]===undefined || o[f]===null || String(o[f]).trim()===''); }

async function userFromRequest(req, env) {
  const m = req.headers.get('Cookie')?.match(/gf_session=([^;]+)/);
  if(!m) return null;
  const th = await hashToken(m[1]);
  return db.prepare(`
    SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id
    WHERE s.token_hash=? AND s.expires_at>? AND u.active=1
  `).bind(th, now()).first();
}
function roleOk(user, roles){ return user && roles.includes(user.role); }
function societyOk(user, societyId){
  return user?.role === 'MASTER_ADMIN' || (user?.society_id && user.society_id === societyId);
}
async function audit(env, user, action, societyId=null, recordId=null, meta={}) {
  await db.prepare(`INSERT INTO audit_logs(id,user_id,role,action,society_id,record_id,metadata_json,created_at)
    VALUES(?,?,?,?,?,?,?,?)`).bind(id('audit'),user?.id||null,user?.role||null,action,societyId,recordId,JSON.stringify(meta),now()).run();
}
function withTenant(user, requested){
  return user.role === 'MASTER_ADMIN' ? requested : user.society_id;
}

async function notify(env, societyId, visitorId, eventType, recipient, payload, channel='WHATSAPP') {
  const settings = await db.prepare(`SELECT notification_json FROM society_settings WHERE society_id=?`).bind(societyId).first();
  let cfg={}; try{cfg=JSON.parse(settings?.notification_json||'{}')}catch{}
  const enabled = cfg[eventType] !== false;
  const provider = cfg.provider || 'queue';
  await db.prepare(`INSERT INTO notifications(id,society_id,visitor_id,channel,event_type,recipient,provider,status,payload_json,created_at)
    VALUES(?,?,?,?,?,?,?,?,?,?)`).bind(id('note'),societyId,visitorId,channel,eventType,recipient,provider,enabled?'queued':'disabled',JSON.stringify(payload),now()).run();
  // Provider-neutral service layer. Integrate a real provider here using Worker secrets.
  return enabled;
}

async function setupStatus(env){
  const row=await db.prepare(`SELECT COUNT(*) n FROM users WHERE role='MASTER_ADMIN'`).first();
  return Number(row?.n||0)===0;
}

async function api(req, env) {
  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/api\/?/, '');
  const method = req.method;

  if(path==='auth/setup-status' && method==='GET') return json({setupRequired: await setupStatus(env)});
  if(path==='auth/setup' && method==='POST'){
    if(!(await setupStatus(env))) return json({error:'Master Admin already configured'},409);
    const b=await body(req);
    if(process.env.MASTER_SETUP_KEY && b.setupKey !== process.env.MASTER_SETUP_KEY) return json({error:'Invalid setup key'},403);
    const missing=requireFields(b,['username','password','name']);
    if(missing) return json({error:`Missing ${missing}`},400);
    if(String(b.password).length<10) return json({error:'Password must be at least 10 characters'},400);
    const hp=await hashPassword(b.password);
    const uid=id('usr');
    await db.prepare(`INSERT INTO users(id,username,password_hash,password_salt,name,mobile,role,active,created_at)
      VALUES(?,?,?,?,?,?,?,?,?)`).bind(uid,b.username.trim(),hp.hash,hp.salt,b.name.trim(),b.mobile||null,'MASTER_ADMIN',1,now()).run();
    await audit(env,{id:uid,role:'MASTER_ADMIN'},'MASTER_ADMIN_CREATED');
    return json({ok:true});
  }
  if(path==='auth/login' && method==='POST'){
    const b=await body(req);
    const u=await db.prepare(`SELECT * FROM users WHERE username=?`).bind(String(b.username||'').trim()).first();
    if(!u || !u.active) return json({error:'Invalid credentials'},401);
    const hp=await hashPassword(String(b.password||''),u.password_salt);
    if(hp.hash!==u.password_hash) return json({error:'Invalid credentials'},401);
    const token=crypto.randomUUID()+crypto.randomUUID();
    const th=await hashToken(token);
    const expires=new Date(Date.now()+Number(process.env.SESSION_DAYS||7)*86400000).toISOString();
    await db.prepare(`INSERT INTO sessions(id,user_id,token_hash,expires_at,created_at) VALUES(?,?,?,?,?)`)
      .bind(id('ses'),u.id,th,expires,now()).run();
    await audit(env,u,'LOGIN',u.society_id,null,{});
    return json({user:{id:u.id,username:u.username,name:u.name,role:u.role,societyId:u.society_id,societyName:null}},
      200,{'Set-Cookie':cookie('gf_session',token,Number(process.env.SESSION_DAYS||7)*86400)});
  }
  if(path==='auth/me' && method==='GET'){
    const u=await userFromRequest(req,env);
    if(!u) return json({user:null});
    let societyName=null;
    if(u.society_id) societyName=(await db.prepare(`SELECT name FROM societies WHERE id=?`).bind(u.society_id).first())?.name||null;
    return json({user:{id:u.id,username:u.username,name:u.name,role:u.role,societyId:u.society_id,societyName}});
  }
  if(path==='auth/logout' && method==='POST'){
    const m=req.headers.get('Cookie')?.match(/gf_session=([^;]+)/);
    if(m) await db.prepare(`DELETE FROM sessions WHERE token_hash=?`).bind(await hashToken(m[1])).run();
    return json({ok:true},200,{'Set-Cookie':cookie('gf_session','',0)});
  }

  const user=await userFromRequest(req,env);
  if(!user) return json({error:'Authentication required'},401);

  if(path==='admin/dashboard' && method==='GET'){
    if(!roleOk(user,['MASTER_ADMIN'])) return json({error:'Forbidden'},403);
    const [soc,active,guards,secs,flats,res,visitors,inside,exited,delivery,maids] = await Promise.all([
      db.prepare(`SELECT COUNT(*) n FROM societies`).first(),
      db.prepare(`SELECT COUNT(*) n FROM societies WHERE active=1`).first(),
      db.prepare(`SELECT COUNT(*) n FROM users WHERE role='GUARD'`).first(),
      db.prepare(`SELECT COUNT(*) n FROM users WHERE role='SOCIETY_SECRETARY'`).first(),
      db.prepare(`SELECT COUNT(*) n FROM flats`).first(),
      db.prepare(`SELECT COUNT(*) n FROM residents WHERE active=1`).first(),
      db.prepare(`SELECT COUNT(*) n FROM visitors WHERE created_at::date=CURRENT_DATE`).first(),
      db.prepare(`SELECT COUNT(*) n FROM visitors WHERE status='Entered'`).first(),
      db.prepare(`SELECT COUNT(*) n FROM visitors WHERE status='Exited' AND exit_at::date=CURRENT_DATE`).first(),
      db.prepare(`SELECT COUNT(*) n FROM visitors v JOIN visitor_types t ON t.id=v.visitor_type_id WHERE v.created_at::date=CURRENT_DATE AND lower(t.name) LIKE '%deliver%'`).first(),
      db.prepare(`SELECT COUNT(*) n FROM visitors v JOIN visitor_types t ON t.id=v.visitor_type_id WHERE v.created_at::date=CURRENT_DATE AND (lower(t.name) LIKE '%maid%' OR lower(t.name) LIKE '%domestic%')`).first()
    ]);
    const recent=await db.prepare(`SELECT v.id,v.name,v.status,v.created_at,v.entry_at,t.name type,s.name society,f.flat_number,b.name block
      FROM visitors v JOIN visitor_types t ON t.id=v.visitor_type_id JOIN societies s ON s.id=v.society_id
      LEFT JOIN flats f ON f.id=v.flat_id LEFT JOIN blocks b ON b.id=f.block_id
      ORDER BY v.created_at DESC LIMIT 12`).all();
    const bySoc=await db.prepare(`SELECT s.id,s.name,s.active,COUNT(v.id) visitors
      FROM societies s LEFT JOIN visitors v ON v.society_id=s.id AND v.created_at::date=CURRENT_DATE
      GROUP BY s.id ORDER BY visitors DESC,s.name`).all();
    return json({stats:{
      societies:soc.n,activeSocieties:active.n,guards:guards.n,secretaries:secs.n,flats:flats.n,residents:res.n,
      todayVisitors:visitors.n,inside:inside.n,exited:exited.n,delivery:delivery.n,maids:maids.n
    },recent:recent.results,societies:bySoc.results});
  }

  if(path==='societies' && method==='GET'){
    if(!roleOk(user,['MASTER_ADMIN'])) return json({error:'Forbidden'},403);
    const r=await db.prepare(`SELECT s.*, (SELECT COUNT(*) FROM flats f WHERE f.society_id=s.id) flat_count,
      (SELECT COUNT(*) FROM users u WHERE u.society_id=s.id AND u.role='GUARD') guard_count,
      (SELECT COUNT(*) FROM residents x WHERE x.society_id=s.id AND x.active=1) resident_count
      FROM societies s ORDER BY s.created_at DESC`).all();
    return json(r.results);
  }
  if(path==='societies' && method==='POST'){
    if(!roleOk(user,['MASTER_ADMIN'])) return json({error:'Forbidden'},403);
    const b=await body(req), missing=requireFields(b,['name']);
    if(missing) return json({error:`Missing ${missing}`},400);
    const sid=id('soc');
    await db.prepare(`INSERT INTO societies(id,name,address,city,state,pin,logo_url,blocks_count,flats_count,contact,emergency_contact,settings_json,created_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(sid,b.name.trim(),b.address||null,b.city||null,b.state||null,b.pin||null,b.logoUrl||null,Number(b.blocksCount||0),Number(b.flatsCount||0),b.contact||null,b.emergencyContact||null,JSON.stringify(b.settings||{}),now()).run();
    await db.prepare(`INSERT INTO society_settings(society_id,notification_json,permission_json,updated_at) VALUES(?,?,?,?)`)
      .bind(sid,JSON.stringify({VISITOR_ENTRY:true,VISITOR_EXIT:false,GUEST_APPROVAL:true,provider:'queue'}),JSON.stringify({}),now()).run();
    await audit(env,user,'CREATE_SOCIETY',sid);
    return json({id:sid});
  }
  if(path.startsWith('societies/') && method==='GET'){
    if(!roleOk(user,['MASTER_ADMIN'])) return json({error:'Forbidden'},403);
    const sid=path.split('/')[1];
    const s=await db.prepare(`SELECT * FROM societies WHERE id=?`).bind(sid).first();
    if(!s) return json({error:'Not found'},404);
    return json(s);
  }

  if(path==='demo/seed' && method==='POST'){
    if(!roleOk(user,['MASTER_ADMIN'])) return json({error:'Forbidden'},403);
    const existing=await db.prepare(`SELECT id FROM societies WHERE name='GateFlow Demo Residency'`).first();
    if(existing) return json({error:'Demo society already exists',societyId:existing.id},409);
    const sid=id('soc'), bid=id('blk'), fid=id('flt'), rid=id('res');
    await db.prepare(`INSERT INTO societies(id,name,address,city,state,pin,contact,emergency_contact,created_at) VALUES(?,?,?,?,?,?,?,?,?)`)
      .bind(sid,'GateFlow Demo Residency','Demo Address','Demo City','Demo State','000000','0000000000','112',now()).run();
    await db.prepare(`INSERT INTO society_settings(society_id,notification_json,permission_json,updated_at) VALUES(?,?,?,?)`)
      .bind(sid,JSON.stringify({VISITOR_ENTRY:true,VISITOR_EXIT:false,GUEST_APPROVAL:true,provider:'queue'}),'{}',now()).run();
    await db.prepare(`INSERT INTO blocks(id,society_id,name,floor_count,created_at) VALUES(?,?,?,?,?)`).bind(bid,sid,'C Block',10,now()).run();
    await db.prepare(`INSERT INTO flats(id,society_id,block_id,flat_number,floor,owner_name,created_at) VALUES(?,?,?,?,?,?,?)`)
      .bind(fid,sid,bid,'H13',8,'Amardeep',now()).run();
    await db.prepare(`INSERT INTO residents(id,society_id,flat_id,name,whatsapp,created_at) VALUES(?,?,?,?,?,?)`)
      .bind(rid,sid,fid,'Amardeep','7985529465',now()).run();
    const types=[['Guest','👥',1,1],['Maid','🧹',0,1],['Delivery','📦',0,1],['Courier','📨',0,1],['Driver','🚗',0,1],['Plumber','🔧',0,1],['Electrician','⚡',0,1],['Other','👤',0,1]];
    for(let i=0;i<types.length;i++){
      const tid=id('vt');
      await db.prepare(`INSERT INTO visitor_types(id,society_id,name,icon,approval_required,flat_required,sort_order,created_at) VALUES(?,?,?,?,?,?,?,?)`)
        .bind(tid,sid,types[i][0],types[i][1],types[i][2],types[i][3],i,now()).run();
      const common=[['Visitor name','name','text',1],['Mobile number','mobile','phone',1]];
      if(types[i][0]==='Delivery') common.push(['Delivery company','delivery_company','text',0],['Parcel/order number','order_number','text',0],['Vehicle number','vehicle_number','vehicle',0]);
      if(types[i][0]==='Guest') common.push(['Purpose','purpose','longtext',0],['Vehicle number','vehicle_number','vehicle',0]);
      for(let j=0;j<common.length;j++){
        await db.prepare(`INSERT INTO visitor_fields(id,visitor_type_id,label,field_key,field_type,required,sort_order,created_at) VALUES(?,?,?,?,?,?,?,?)`)
          .bind(id('vf'),tid,common[j][0],common[j][1],common[j][2],common[j][3],j,now()).run();
      }
    }
    const guardHash=await hashPassword('Guard@12345'), secHash=await hashPassword('Secretary@12345');
    const gid=id('usr'), seid=id('usr');
    await db.prepare(`INSERT INTO users(id,username,password_hash,password_salt,name,mobile,role,society_id,active,shift,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
      .bind(gid,'demo.guard',guardHash.hash,guardHash.salt,'Demo Guard','9000000001','GUARD',sid,1,'Day',now()).run();
    await db.prepare(`INSERT INTO users(id,username,password_hash,password_salt,name,mobile,role,society_id,active,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)`)
      .bind(seid,'demo.secretary',secHash.hash,secHash.salt,'Demo Secretary','9000000002','SOCIETY_SECRETARY',sid,1,now()).run();
    await audit(env,user,'SEED_DEMO',sid);
    return json({ok:true,societyId:sid,credentials:{guard:'demo.guard / Guard@12345',secretary:'demo.secretary / Secretary@12345'}});
  }

  const societyId = user.society_id;
  if(path==='portal' && method==='GET'){
    if(!roleOk(user,['GUARD','SOCIETY_SECRETARY'])) return json({error:'Forbidden'},403);
    const s=await db.prepare(`SELECT * FROM societies WHERE id=?`).bind(societyId).first();
    const types=await db.prepare(`SELECT * FROM visitor_types WHERE society_id=? AND active=1 ORDER BY sort_order,name`).bind(societyId).all();
    return json({society:s,types:types.results});
  }

  if(path==='blocks' && method==='GET'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY','GUARD'])) return json({error:'Forbidden'},403);
    const sid=withTenant(user,new URL(req.url).searchParams.get('societyId'));
    if(!societyOk(user,sid)) return json({error:'Forbidden'},403);
    const r=await db.prepare(`SELECT * FROM blocks WHERE society_id=? ORDER BY name`).bind(sid).all(); return json(r.results);
  }
  if(path==='blocks' && method==='POST'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY'])) return json({error:'Forbidden'},403);
    const b=await body(req), sid=withTenant(user,b.societyId);
    if(!societyOk(user,sid)) return json({error:'Forbidden'},403);
    const bid=id('blk');
    await db.prepare(`INSERT INTO blocks(id,society_id,name,floor_count,created_at) VALUES(?,?,?,?,?)`).bind(bid,sid,b.name.trim(),Number(b.floorCount||0),now()).run();
    await audit(env,user,'CREATE_BLOCK',sid,bid); return json({id:bid});
  }

  if(path==='flats' && method==='GET'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY','GUARD'])) return json({error:'Forbidden'},403);
    const sid=withTenant(user,new URL(req.url).searchParams.get('societyId'));
    if(!societyOk(user,sid)) return json({error:'Forbidden'},403);
    const r=await db.prepare(`SELECT f.*,b.name block_name,(SELECT COUNT(*) FROM residents r WHERE r.flat_id=f.id AND r.active=1) residents
      FROM flats f JOIN blocks b ON b.id=f.block_id WHERE f.society_id=? ORDER BY b.name,f.flat_number`).bind(sid).all(); return json(r.results);
  }
  if(path==='flats' && method==='POST'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY'])) return json({error:'Forbidden'},403);
    const b=await body(req), sid=withTenant(user,b.societyId);
    if(!societyOk(user,sid)) return json({error:'Forbidden'},403);
    const fid=id('flt');
    await db.prepare(`INSERT INTO flats(id,society_id,block_id,flat_number,floor,owner_name,resident_type,created_at) VALUES(?,?,?,?,?,?,?,?)`)
      .bind(fid,sid,b.blockId,b.flatNumber.trim(),Number(b.floor||0),b.ownerName||null,b.residentType||null,now()).run();
    await audit(env,user,'CREATE_FLAT',sid,fid); return json({id:fid});
  }

  if(path==='residents' && method==='GET'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY','GUARD'])) return json({error:'Forbidden'},403);
    const sid=withTenant(user,new URL(req.url).searchParams.get('societyId'));
    if(!societyOk(user,sid)) return json({error:'Forbidden'},403);
    const q=new URL(req.url).searchParams.get('q')||'';
    const r=await db.prepare(`SELECT r.*,f.flat_number,b.name block_name FROM residents r JOIN flats f ON f.id=r.flat_id JOIN blocks b ON b.id=f.block_id
      WHERE r.society_id=? AND r.active=1 AND (r.name LIKE ? OR f.flat_number LIKE ? OR b.name LIKE ?) ORDER BY r.name LIMIT 100`)
      .bind(sid,escLike(q),escLike(q),escLike(q)).all(); return json(r.results);
  }
  if(path==='residents' && method==='POST'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY'])) return json({error:'Forbidden'},403);
    const b=await body(req), sid=withTenant(user,b.societyId);
    if(!societyOk(user,sid)) return json({error:'Forbidden'},403);
    const rid=id('res');
    await db.prepare(`INSERT INTO residents(id,society_id,flat_id,name,mobile,whatsapp,alternate_number,email,family_members,vehicle_details,resident_type,created_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?)`).bind(rid,sid,b.flatId,b.name.trim(),b.mobile||null,b.whatsapp||null,b.alternateNumber||null,b.email||null,b.familyMembers||null,b.vehicleDetails||null,b.residentType||null,now()).run();
    await audit(env,user,'CREATE_RESIDENT',sid,rid); return json({id:rid});
  }

  if(path==='visitor-types' && method==='GET'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY','GUARD'])) return json({error:'Forbidden'},403);
    const sid=withTenant(user,new URL(req.url).searchParams.get('societyId'));
    if(!societyOk(user,sid)) return json({error:'Forbidden'},403);
    const r=await db.prepare(`SELECT * FROM visitor_types WHERE society_id=? AND active=1 ORDER BY sort_order,name`).bind(sid).all();
    return json(r.results);
  }
  if(path==='visitor-types' && method==='POST'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY'])) return json({error:'Forbidden'},403);
    const b=await body(req), sid=withTenant(user,b.societyId);
    if(!societyOk(user,sid)) return json({error:'Forbidden'},403);
    const tid=id('vt');
    await db.prepare(`INSERT INTO visitor_types(id,society_id,name,icon,color,description,photo_required,flat_required,approval_required,id_required,vehicle_required,phone_required,sort_order,created_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(tid,sid,b.name.trim(),b.icon||'👤',b.color||'#4F46E5',b.description||null,b.photoRequired?1:0, b.flatRequired!==false?1:0,b.approvalRequired?1:0,b.idRequired?1:0,b.vehicleRequired?1:0,b.phoneRequired!==false?1:0,Number(b.sortOrder||0),now()).run();
    await audit(env,user,'CREATE_VISITOR_TYPE',sid,tid); return json({id:tid});
  }
  if(path.startsWith('visitor-types/') && path.endsWith('/fields') && method==='GET'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY','GUARD'])) return json({error:'Forbidden'},403);
    const tid=path.split('/')[1];
    const t=await db.prepare(`SELECT society_id FROM visitor_types WHERE id=?`).bind(tid).first();
    if(!t || !societyOk(user,t.society_id)) return json({error:'Forbidden'},403);
    const r=await db.prepare(`SELECT * FROM visitor_fields WHERE visitor_type_id=? AND active=1 ORDER BY sort_order`).bind(tid).all(); return json(r.results);
  }
  if(path.startsWith('visitor-types/') && path.endsWith('/fields') && method==='POST'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY'])) return json({error:'Forbidden'},403);
    const tid=path.split('/')[1], t=await db.prepare(`SELECT society_id FROM visitor_types WHERE id=?`).bind(tid).first();
    if(!t || !societyOk(user,t.society_id)) return json({error:'Forbidden'},403);
    const b=await body(req), fid=id('vf');
    await db.prepare(`INSERT INTO visitor_fields(id,visitor_type_id,label,field_key,field_type,required,options_json,sort_order,created_at)
      VALUES(?,?,?,?,?,?,?,?,?)`).bind(fid,tid,b.label.trim(),b.fieldKey.trim(),b.fieldType||'text',b.required?1:0,JSON.stringify(b.options||[]),Number(b.sortOrder||0),now()).run();
    await audit(env,user,'CREATE_VISITOR_FIELD',t.society_id,fid); return json({id:fid});
  }

  if(path==='users' && method==='GET'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY'])) return json({error:'Forbidden'},403);
    const sid=withTenant(user,new URL(req.url).searchParams.get('societyId'));
    if(!societyOk(user,sid)) return json({error:'Forbidden'},403);
    const r=await db.prepare(`SELECT id,username,name,mobile,role,active,shift,created_at FROM users WHERE society_id=? ORDER BY role,name`).bind(sid).all(); return json(r.results);
  }
  if(path==='users' && method==='POST'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY'])) return json({error:'Forbidden'},403);
    const b=await body(req), sid=withTenant(user,b.societyId);
    if(!societyOk(user,sid)) return json({error:'Forbidden'},403);
    if(!['GUARD','SOCIETY_SECRETARY'].includes(b.role)) return json({error:'Invalid role'},400);
    if(String(b.password||'').length<10) return json({error:'Password must be at least 10 characters'},400);
    const hp=await hashPassword(b.password), uid=id('usr');
    await db.prepare(`INSERT INTO users(id,username,password_hash,password_salt,name,mobile,role,society_id,active,shift,created_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?)`).bind(uid,b.username.trim(),hp.hash,hp.salt,b.name.trim(),b.mobile||null,b.role,sid,1,b.shift||null,now()).run();
    await audit(env,user,'CREATE_USER',sid,uid,{role:b.role}); return json({id:uid});
  }
  if(path.startsWith('users/') && path.endsWith('/status') && method==='POST'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY'])) return json({error:'Forbidden'},403);
    const uid=path.split('/')[1], target=await db.prepare(`SELECT * FROM users WHERE id=?`).bind(uid).first();
    if(!target || !societyOk(user,target.society_id)) return json({error:'Forbidden'},403);
    const b=await body(req);
    await db.prepare(`UPDATE users SET active=? WHERE id=?`).bind(b.active?1:0,uid).run();
    await audit(env,user,b.active?'ENABLE_USER':'DISABLE_USER',target.society_id,uid); return json({ok:true});
  }

  if(path==='visitors' && method==='GET'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY','GUARD'])) return json({error:'Forbidden'},403);
    const p=new URL(req.url).searchParams, sid=withTenant(user,p.get('societyId'));
    if(!societyOk(user,sid)) return json({error:'Forbidden'},403);
    const q=p.get('q')||'', status=p.get('status')||'', type=p.get('type')||'';
    const limit=Math.min(Number(p.get('limit')||100),200);
    let sql=`SELECT v.*,t.name type,t.icon,f.flat_number,b.name block_name,r.name resident_name,
      eu.name entry_guard_name,xu.name exit_guard_name
      FROM visitors v JOIN visitor_types t ON t.id=v.visitor_type_id
      LEFT JOIN flats f ON f.id=v.flat_id LEFT JOIN blocks b ON b.id=f.block_id LEFT JOIN residents r ON r.id=v.resident_id
      LEFT JOIN users eu ON eu.id=v.entry_guard_id LEFT JOIN users xu ON xu.id=v.exit_guard_id
      WHERE v.society_id=?`;
    const args=[sid];
    if(q){sql+=` AND (v.name LIKE ? OR v.mobile LIKE ? OR f.flat_number LIKE ? OR b.name LIKE ? OR v.id LIKE ?)`; for(let i=0;i<5;i++)args.push(escLike(q))}
    if(status){sql+=` AND v.status=?`;args.push(status)}
    if(type){sql+=` AND v.visitor_type_id=?`;args.push(type)}
    sql+=` ORDER BY v.created_at DESC LIMIT ?`;args.push(limit);
    const r=await db.prepare(sql).bind(...args).all(); return json(r.results);
  }
  if(path==='visitors' && method==='POST'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY','GUARD'])) return json({error:'Forbidden'},403);
    const b=await body(req), sid=withTenant(user,b.societyId);
    if(!societyOk(user,sid)) return json({error:'Forbidden'},403);
    const type=await db.prepare(`SELECT * FROM visitor_types WHERE id=? AND society_id=? AND active=1`).bind(b.visitorTypeId,sid).first();
    if(!type) return json({error:'Invalid visitor type'},400);
    if(type.flat_required && !b.flatId) return json({error:'Flat is required'},400);
    if(type.phone_required && !b.mobile) return json({error:'Phone number is required'},400);
    if(type.photo_required && !b.photoKey) return json({error:'Photo is required'},400);
    let resident=null;
    if(b.residentId) resident=await db.prepare(`SELECT * FROM residents WHERE id=? AND society_id=?`).bind(b.residentId,sid).first();
    const vid=id('vis');
    const status=type.approval_required?'Waiting':'Entered', entry=type.approval_required?null:now();
    await db.prepare(`INSERT INTO visitors(id,society_id,visitor_type_id,flat_id,resident_id,name,mobile,vehicle_number,id_number,photo_key,custom_data_json,status,entry_at,entry_guard_id,created_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).bind(vid,sid,type.id,b.flatId||null,resident?.id||null,b.name.trim(),b.mobile||null,b.vehicleNumber||null,b.idNumber||null,b.photoKey||null,JSON.stringify(b.customData||{}),status,entry,status==='Entered'?user.id:null,now()).run();
    if(type.approval_required){
      await db.prepare(`INSERT INTO approvals(id,visitor_id,resident_id,status,created_at) VALUES(?,?,?,?,?)`).bind(id('apr'),vid,resident?.id||null,'Waiting',now()).run();
      await notify(env,sid,vid,'GUEST_APPROVAL',resident?.whatsapp||resident?.mobile||null,{visitor:b.name,type:type.name,flatId:b.flatId,entryTime:now()});
    } else if(resident){
      await notify(env,sid,vid,'VISITOR_ENTRY',resident.whatsapp||resident.mobile||null,{visitor:b.name,type:type.name,flatId:b.flatId,entryTime:entry});
    }
    await audit(env,user,'REGISTER_VISITOR',sid,vid,{status});
    return json({id:vid,status,entryAt:entry});
  }

  if(path.startsWith('visitors/') && path.endsWith('/exit') && method==='POST'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY','GUARD'])) return json({error:'Forbidden'},403);
    const vid=path.split('/')[1], v=await db.prepare(`SELECT * FROM visitors WHERE id=?`).bind(vid).first();
    if(!v || !societyOk(user,v.society_id)) return json({error:'Forbidden'},403);
    if(v.status!=='Entered') return json({error:'Visitor is not currently inside'},400);
    const at=now();
    await db.prepare(`UPDATE visitors SET status='Exited',exit_at=?,exit_guard_id=? WHERE id=?`).bind(at,user.id,vid).run();
    await audit(env,user,'MARK_VISITOR_EXIT',v.society_id,vid);
    return json({ok:true,exitAt:at});
  }

  if(path.startsWith('visitors/') && path.endsWith('/approve') && method==='POST'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY'])) return json({error:'Forbidden'},403);
    const vid=path.split('/')[1], v=await db.prepare(`SELECT * FROM visitors WHERE id=?`).bind(vid).first();
    if(!v || !societyOk(user,v.society_id)) return json({error:'Forbidden'},403);
    const b=await body(req), approved=!!b.approved, status=approved?'Approved':'Rejected';
    await db.prepare(`UPDATE approvals SET status=?,decided_at=?,note=? WHERE visitor_id=?`).bind(status,now(),b.note||null,vid).run();
    if(approved) await db.prepare(`UPDATE visitors SET status='Approved' WHERE id=?`).bind(vid).run();
    else await db.prepare(`UPDATE visitors SET status='Rejected' WHERE id=?`).bind(vid).run();
    await audit(env,user,approved?'APPROVE_VISITOR':'REJECT_VISITOR',v.society_id,vid);
    return json({ok:true,status});
  }

  if(path==='dashboard' && method==='GET'){
    if(!roleOk(user,['GUARD','SOCIETY_SECRETARY'])) return json({error:'Forbidden'},403);
    const sid=user.society_id;
    const [today,inside,exits,total,types]=await Promise.all([
      db.prepare(`SELECT COUNT(*) n FROM visitors WHERE society_id=? AND created_at::date=CURRENT_DATE`).bind(sid).first(),
      db.prepare(`SELECT COUNT(*) n FROM visitors WHERE society_id=? AND status='Entered'`).bind(sid).first(),
      db.prepare(`SELECT COUNT(*) n FROM visitors WHERE society_id=? AND status='Exited' AND exit_at::date=CURRENT_DATE`).bind(sid).first(),
      db.prepare(`SELECT COUNT(*) n FROM visitors WHERE society_id=?`).bind(sid).first(),
      db.prepare(`SELECT t.name type,COUNT(v.id) count FROM visitor_types t LEFT JOIN visitors v ON v.visitor_type_id=t.id AND v.created_at::date=CURRENT_DATE WHERE t.society_id=? GROUP BY t.id ORDER BY count DESC`).bind(sid).all()
    ]);
    return json({today:today.n,inside:inside.n,exits:exits.n,total:total.n,types:types.results});
  }

  if(path==='reports/csv' && method==='GET'){
    if(!roleOk(user,['MASTER_ADMIN','SOCIETY_SECRETARY'])) return json({error:'Forbidden'},403);
    const p=new URL(req.url).searchParams,sid=withTenant(user,p.get('societyId'));
    if(!societyOk(user,sid)) return json({error:'Forbidden'},403);
    const rows=await db.prepare(`SELECT v.id,v.name,t.name type,v.mobile,b.name block,f.flat_number,r.name resident_name,
      v.status,v.entry_at,v.exit_at,v.created_at FROM visitors v JOIN visitor_types t ON t.id=v.visitor_type_id
      LEFT JOIN flats f ON f.id=v.flat_id LEFT JOIN blocks b ON b.id=f.block_id LEFT JOIN residents r ON r.id=v.resident_id
      WHERE v.society_id=? ORDER BY v.created_at DESC LIMIT 5000`).bind(sid).all();
    const cols=['id','name','type','mobile','block','flat_number','resident_name','status','entry_at','exit_at','created_at'];
    const csv=[cols.join(','),...rows.results.map(r=>cols.map(c=>`"${String(r[c]??'').replaceAll('"','""')}"`).join(','))].join('\n');
    return new Response(csv,{headers:{'content-type':'text/csv; charset=utf-8','content-disposition':'attachment; filename="gateflow-visitors.csv"'}});
  }

  return json({error:'Not found'},404);
}

export default async function handler(req) {
  const env = {}; // placeholder — Cloudflare-specific bindings were replaced above
  try {
    return await api(req, env);
  } catch (e) {
    console.error(e);
    return json({ error: 'Server error', detail: String(e.message || e) }, 500);
  }
}
